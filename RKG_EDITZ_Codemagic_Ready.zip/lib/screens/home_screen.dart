import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/action_card.dart';
import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _newProject(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const EditorScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(Icons.menu),
        title: const Text(
          'RKG EDITZ',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: const [
          Icon(Icons.notifications_none),
          SizedBox(width: 18),
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Image.asset(
                'assets/images/rkg_editz_logo.png',
                height: 250,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 18),
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => _newProject(context),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.yellow, Color(0xFFFF8A00)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.black,
                      child: Icon(Icons.add, color: AppTheme.yellow, size: 32),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('NEW PROJECT',
                              style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w900)),
                          SizedBox(height: 4),
                          Text('Start editing your next video',
                              style: TextStyle(color: Colors.black87)),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios, color: Colors.black),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            const Text('EDIT', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.2,
              children: [
                ActionCard(icon: Icons.movie_creation_outlined, title: 'Video Edit', subtitle: 'Trim & cut', onTap: () => _newProject(context)),
                ActionCard(icon: Icons.photo_outlined, title: 'Photo Edit', subtitle: 'HD photo tools', onTap: () {}),
                ActionCard(icon: Icons.auto_awesome_motion, title: 'Templates', subtitle: 'Reels templates', onTap: () {}),
                ActionCard(icon: Icons.music_note, title: 'Music', subtitle: 'Add your music', onTap: () {}),
              ],
            ),
            const SizedBox(height: 24),
            const Text('QUICK TOOLS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: const [
                _ToolChip(icon: Icons.content_cut, label: 'Trim'),
                _ToolChip(icon: Icons.call_split, label: 'Split'),
                _ToolChip(icon: Icons.text_fields, label: 'Text'),
                _ToolChip(icon: Icons.auto_awesome, label: 'Effects'),
                _ToolChip(icon: Icons.tune, label: 'Filters'),
                _ToolChip(icon: Icons.speed, label: 'Speed'),
              ],
            ),
            const SizedBox(height: 28),
            const Text('MY PROJECTS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            _ProjectTile(title: 'New Project', subtitle: 'Ready to edit'),
            _ProjectTile(title: 'RKG Promo', subtitle: '30 sec'),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'Projects'),
          NavigationDestination(icon: Icon(Icons.video_library_outlined), selectedIcon: Icon(Icons.video_library), label: 'Templates'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class _ToolChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ToolChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Chip(
    avatar: const Icon(AppTheme.yellow, size: 18),
    label: Text(label),
    side: const BorderSide(color: Colors.white12),
  );
}

class _ProjectTile extends StatelessWidget {
  final String title;
  final String subtitle;
  const _ProjectTile({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const CircleAvatar(
        backgroundColor: AppTheme.yellow,
        child: Icon(Icons.play_arrow, color: Colors.black),
      ),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.more_vert),
    ),
  );
}
