import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../theme/app_theme.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final ImagePicker _picker = ImagePicker();
  VideoPlayerController? _controller;
  File? _video;
  bool _loading = false;

  Future<void> _pickVideo() async {
    setState(() => _loading = true);
    try {
      final picked = await _picker.pickVideo(source: ImageSource.gallery);
      if (picked == null) return;

      await _controller?.dispose();
      final controller = VideoPlayerController.file(File(picked.path));
      await controller.initialize();

      setState(() {
        _video = File(picked.path);
        _controller = controller;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open video: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;

    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(),
        title: const Text(
          'RKG EDITZ Editor',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: AppTheme.yellow,
              foregroundColor: Colors.black,
            ),
            onPressed: _showExport,
            child: const Text('EXPORT HD'),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white12),
              ),
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : controller == null
                      ? _EmptyPreview(onImport: _pickVideo)
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              AspectRatio(
                                aspectRatio: controller.value.aspectRatio,
                                child: VideoPlayer(controller),
                              ),
                              FloatingActionButton(
                                backgroundColor: AppTheme.yellow,
                                foregroundColor: Colors.black,
                                onPressed: () {
                                  setState(() {
                                    controller.value.isPlaying
                                        ? controller.pause()
                                        : controller.play();
                                  });
                                },
                                child: Icon(
                                  controller.value.isPlaying
                                      ? Icons.pause
                                      : Icons.play_arrow,
                                ),
                              ),
                            ],
                          ),
                        ),
            ),
          ),
          if (controller != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: VideoProgressIndicator(
                controller,
                allowScrubbing: true,
                colors: const VideoProgressColors(
                  playedColor: AppTheme.yellow,
                  bufferedColor: Colors.white30,
                  backgroundColor: Colors.white12,
                ),
              ),
            ),
          const SizedBox(height: 10),
          Container(
            height: 92,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const _TrackLabel(icon: Icons.movie, label: 'VIDEO'),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(
                        _video == null
                            ? 'Import a video'
                            : 'Video timeline • ${_video!.path.split('/').last}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 86,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _EditButton(Icons.file_upload_outlined, 'Import', _pickVideo),
                _EditButton(Icons.content_cut, 'Trim', () => _comingSoon('Trim')),
                _EditButton(Icons.call_split, 'Split', () => _comingSoon('Split')),
                _EditButton(Icons.speed, 'Speed', () => _comingSoon('Speed')),
                _EditButton(Icons.music_note, 'Music', () => _comingSoon('Music')),
                _EditButton(Icons.text_fields, 'Text', () => _comingSoon('Text')),
                _EditButton(Icons.auto_awesome, 'Effects', () => _comingSoon('Effects')),
                _EditButton(Icons.tune, 'Filters', () => _comingSoon('Filters')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _comingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature tool — next development step')),
    );
  }

  void _showExport() {
    showModalBottomSheet(
      context: context,
      builder: (_) => const Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Export Video',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 18),
            ListTile(
              leading: Icon(Icons.hd),
              title: Text('1080p HD'),
              subtitle: Text('Export engine will be connected next'),
            ),
            ListTile(
              leading: Icon(Icons.sd),
              title: Text('720p'),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyPreview extends StatelessWidget {
  final VoidCallback onImport;
  const _EmptyPreview({required this.onImport});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: AppTheme.yellow,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        ),
        onPressed: onImport,
        icon: const Icon(Icons.video_library_outlined),
        label: const Text('IMPORT VIDEO'),
      ),
    );
  }
}

class _TrackLabel extends StatelessWidget {
  final IconData icon;
  final String label;
  const _TrackLabel({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 72,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppTheme.yellow),
            Text(label, style: const TextStyle(fontSize: 10)),
          ],
        ),
      );
}

class _EditButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _EditButton(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(
          width: 78,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: AppTheme.yellow),
              const SizedBox(height: 6),
              Text(label, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      );
}
