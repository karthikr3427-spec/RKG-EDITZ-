import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const RkgEditzApp());
}

class RkgEditzApp extends StatelessWidget {
  const RkgEditzApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RKG EDITZ',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const HomeScreen(),
    );
  }
}
