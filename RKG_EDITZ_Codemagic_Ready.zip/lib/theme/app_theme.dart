import 'package:flutter/material.dart';

class AppTheme {
  static const yellow = Color(0xFFFFC400);
  static const background = Color(0xFF080808);
  static const surface = Color(0xFF151515);

  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: ColorScheme.fromSeed(
        seedColor: yellow,
        brightness: Brightness.dark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
      ),
      useMaterial3: true,
    );
  }
}
