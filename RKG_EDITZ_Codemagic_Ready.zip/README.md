# RKG EDITZ — First Working Version

Cross-platform Flutter starter for Android + iPhone.

## Current version — 0.2
This starter contains:
- RKG EDITZ branding and supplied logo asset
- Home screen
- New Project flow
- Editor screen UI
- Real gallery video picker
- Local video preview/play-pause
- Scrubbable video progress bar
- Timeline mockup
- Trim / Split / Speed / Music / Text / Effects / Filters / Crop tool buttons
- HD export selection UI
- Projects and templates navigation placeholders

## Next development phase
Add real media functionality:
1. Video/photo picker
2. Video playback
3. Timeline model
4. Trim and split processing
5. Audio/music track
6. Text overlays
7. Filters/effects
8. 1080p export
9. Save/load projects
10. Android and iOS release configuration

## Run
Install Flutter, then:
flutter pub get
flutter run
